// Wait for the DOM to be fully loaded before running the script
document.addEventListener('DOMContentLoaded', () => {

    // === 1. STATE MANAGEMENT ===
    // (Simulating a database)

    // Hardcoded product data
    const products = [
        { id: 1, title: 'The Great Gatsby', price: 10.99, img: 'https://via.placeholder.com/150/FF5733/FFFFFF?text=Book1' },
        { id: 2, title: 'To Kill a Mockingbird', price: 12.50, img: 'https://via.placeholder.com/150/33FF57/FFFFFF?text=Book2' },
        { id: 3, title: '1984', price: 8.99, img: 'https://via.placeholder.com/150/3357FF/FFFFFF?text=Book3' },
        { id: 4, title: 'Pride and Prejudice', price: 7.99, img: 'https://via.placeholder.com/150/FF33A1/FFFFFF?text=Book4' }
    ];

    // This array will hold the items in the cart
    let cart = [];
    let isLoggedIn = false;

    // === 2. DOM ELEMENT REFERENCES ===
    // Get all the different 'views'
    const views = document.querySelectorAll('.view');
    const productListView = document.getElementById('product-list-view');
    const productGrid = document.getElementById('product-grid');
    const cartItemsContainer = document.getElementById('cart-items-container');
    const cartTotalEl = document.getElementById('cart-total');
    const cartCountEl = document.getElementById('cart-count');
    
    // Get nav links
    const navLoginLink = document.getElementById('nav-login-link');
    const navLogoutLink = document.getElementById('nav-logout-link');
    const navHomeLink = document.getElementById('nav-home-link');
    const navCartLink = document.getElementById('nav-cart-link');

    // Get forms
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const checkoutForm = document.getElementById('checkout-form');

    // Get links and buttons
    const showRegisterLink = document.getElementById('show-register-link');
    const showLoginLink = document.getElementById('show-login-link');
    const checkoutBtn = document.getElementById('checkout-btn');
    const confirmOrderBtn = document.getElementById('confirm-order-btn');
    const backToHomeBtn = document.getElementById('back-to-home-btn');


    // === 3. CORE FUNCTIONS ===

    /**
     * Shows a specific view by its ID and hides all others.
     * This is the core of the "single-page application" (SPA) logic.
     * It matches the flow in your Activity Diagram.
     */
    function showView(viewId) {
        views.forEach(view => {
            view.classList.remove('active');
        });
        document.getElementById(viewId).classList.add('active');
    }

    /**
     * Updates the navigation bar based on login state
     */
    function updateNav() {
        if (isLoggedIn) {
            navLoginLink.style.display = 'none';
            navLogoutLink.style.display = 'block';
            navHomeLink.style.display = 'block';
            navCartLink.style.display = 'block';
        } else {
            navLoginLink.style.display = 'block';
            navLogoutLink.style.display = 'none';
            navHomeLink.style.display = 'none';
            navCartLink.style.display = 'none';
        }
    }

    /**
     * Renders all products from the 'products' array into the product grid.
     * This is DOM Manipulation.
     */
    function renderProducts() {
        productGrid.innerHTML = ''; // Clear existing grid
        products.forEach(product => {
            productGrid.innerHTML += `
                <div class="product-card">
                    <img src="${product.img}" alt="${product.title}">
                    <h3>${product.title}</h3>
                    <p class="price">$${product.price.toFixed(2)}</p>
                    <button class="add-to-cart-btn" data-id="${product.id}">Add to Cart</button>
                </div>
            `;
        });
    }

    /**
     * Renders the items in the 'cart' array into the cart view.
     * This is DOM Manipulation and matches the 'ViewShoppingCart' use case.
     */
    function renderCart() {
        cartItemsContainer.innerHTML = ''; // Clear cart
        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
            cartTotalEl.textContent = '0.00';
            return;
        }

        let total = 0;
        cart.forEach(item => {
            cartItemsContainer.innerHTML += `
                <div class="cart-item">
                    <div class="cart-item-info">
                        <strong>${item.title}</strong>
                        <span>(Qty: ${item.quantity})</span>
                    </div>
                    <span>$${(item.price * item.quantity).toFixed(2)}</span>
                </div>
            `;
            total += item.price * item.quantity;
        });

        cartTotalEl.textContent = total.toFixed(2);
    }

    /**
     * Updates the small number on the cart icon in the nav.
     */
    function updateCartCount() {
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCountEl.textContent = totalItems;
    }

    /**
     * Handles the 'AddBook'/'AddToCart' logic from your diagrams.
     */
    function addToCart(productId) {
        // Find if item is already in cart
        const existingItem = cart.find(item => item.id === productId);

        if (existingItem) {
            // Increment quantity
            existingItem.quantity++;
        } else {
            // Find product from products list and add to cart
            const product = products.find(p => p.id === productId);
            cart.push({ ...product, quantity: 1 });
        }
        
        updateCartCount();
        console.log('Cart:', cart); // For debugging
    }

    // === 4. EVENT LISTENERS ===
    // (This connects your UML flows to user actions)

    // Navigation Event Listeners
    navLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        showView('login-view');
    });

    navLogoutLink.addEventListener('click', (e) => {
        e.preventDefault();
        isLoggedIn = false;
        cart = []; // Clear cart on logout
        updateCartCount();
        renderCart();
        updateNav();
        showView('login-view');
    });

    navHomeLink.addEventListener('click', (e) => {
        e.preventDefault();
        showView('product-list-view');
    });

    navCartLink.addEventListener('click', (e) => {
        e.preventDefault();
        renderCart(); // Re-render cart every time it's viewed
        showView('cart-view');
    });

    // Form and Link Event Listeners
    showRegisterLink.addEventListener('click', (e) => {
        e.preventDefault();
        showView('register-view');
    });

    showLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        showView('login-view');
    });

    // Logic for 'Login' (from Activity/Use Case)
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault(); // Prevent actual form submission
        console.log('Login attempt');
        // --- In a real app, you'd verify credentials here ---
        isLoggedIn = true;
        updateNav();
        showView('product-list-view');
    });

    // Logic for 'Register' (from Activity/Use Case)
    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        console.log('Registration attempt');
        // --- In a real app, you'd create a new user here ---
        isLoggedIn = true;
        updateNav();
        showView('product-list-view');
    });

    // Event Delegation for 'Add to Cart' buttons
    productListView.addEventListener('click', (e) => {
        if (e.target.classList.contains('add-to-cart-btn')) {
            const productId = parseInt(e.target.dataset.id);
            addToCart(productId);
            alert('Book added to cart!'); // Simple user feedback
        }
    });

    // Logic for 'Proceed to Checkout' (from Activity/Sequence)
    checkoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (cart.length === 0) {
            alert('Your cart is empty.');
            return;
        }
        showView('checkout-view');
    });

    // Logic for 'Confirm Order' (from Activity/Sequence)
    checkoutForm.addEventListener('submit', (e) => {
        e.preventDefault();
        console.log('Order Confirmed');
        // --- In a real app, you'd process payment here ---
        cart = []; // Clear the cart
        updateCartCount();
        renderCart();
        showView('order-summary-view');
    });

    backToHomeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        showView('product-list-view');
    });


    // === 5. INITIALIZATION ===
    // (Code to run on page load)

    renderProducts();
    updateNav();
    showView('login-view'); // Start on the login view

});